﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public class Singleton
    {
        // Variable estática para la instancia, se necesita utilizar una función lambda ya que el constructor es privado
        private static readonly Lazy<Singleton> instance = new Lazy<Singleton>(() => new Singleton());

        // Constructor privado para evitar la instanciación directa
        private Singleton()
        {
        }

        // Propiedad para acceder a la instancia
        public static Singleton Instance
        {
            get
            {
                return instance.Value;
            }
        }

        public string Metodo1()
        {
            return ("Metodo1");
        }
        public string Metodo2()
        {
            return ("Metodo2");
        }
    }
}
