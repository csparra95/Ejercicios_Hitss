﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ConsoleApp5
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection conexion = new SqlConnection("server = HGDLAPARRACS\\SQLEXPRESS ; database=SPOTIFY ; integrated security = true");
            conexion.Open();
            string cadena = " SELECT * FROM PLAYL_CANCIONES";
           
            SqlCommand comando = new SqlCommand(cadena, conexion);
            
            SqlDataReader registros = comando.ExecuteReader();
          

            while (registros.Read())
            {
                Console.Write(registros["PLAYLIST_ID"]);
                Console.Write("--");
               
                Console.WriteLine(registros["CANCION_ID"]);
                Console.WriteLine(" ");
            }

            Console.ReadKey();


        }
    }
}
