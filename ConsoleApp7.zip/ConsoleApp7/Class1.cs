﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    public class Cancion
    {
        public int ID;
        public string Name;
        public string Artista;
        public string Genero;  

    }
}
